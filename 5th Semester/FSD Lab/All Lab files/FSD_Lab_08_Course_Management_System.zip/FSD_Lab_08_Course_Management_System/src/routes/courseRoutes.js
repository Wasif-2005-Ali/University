/**
 * Course routes.
 *
 *  GET    /api/courses      (any authenticated user) — Req. 9: students view courses
 *  GET    /api/courses/:id  (any authenticated user)
 *  POST   /api/courses      (admin only) — Req. 13
 *  PUT    /api/courses/:id  (admin only) — Req. 13
 *  DELETE /api/courses/:id  (admin only) — Req. 13
 *
 * Students hitting a write endpoint get 403 FORBIDDEN from the
 * authorizeRole middleware (Req. 14) — the check is on the backend,
 * so hiding buttons in the UI is never the only protection.
 */
const express = require('express');
const { pool } = require('../config/db');
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const { validateCourse } = require('../utils/validation');

const router = express.Router();

// All course routes require a valid JWT (Req. 10).
router.use(authenticateToken);

function publicCourse(row) {
  return {
    id: row.id,
    courseCode: row.course_code,
    courseName: row.course_name,
    instructor: row.instructor,
    credits: row.credits,
    description: row.description,
    createdAt: row.created_at,
  };
}

// ── GET /api/courses — list all courses ────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const search = String(req.query.search || '').trim();
    let rows;
    if (search) {
      // Parameterised LIKE search across code, name and instructor.
      const like = `%${search}%`;
      [rows] = await pool.execute(
        `SELECT * FROM courses
         WHERE course_code LIKE ? OR course_name LIKE ? OR instructor LIKE ?
         ORDER BY course_code ASC`,
        [like, like, like]
      );
    } else {
      [rows] = await pool.execute('SELECT * FROM courses ORDER BY course_code ASC');
    }
    return res.json({ success: true, count: rows.length, courses: rows.map(publicCourse) });
  } catch (err) {
    console.error('List courses error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// ── GET /api/courses/:id — single course ───────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM courses WHERE id = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Course not found.' });
    }
    return res.json({ success: true, course: publicCourse(rows[0]) });
  } catch (err) {
    console.error('Get course error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// ── POST /api/courses — add a course (admin only) ──────────────────────
router.post('/', authorizeRole('admin'), async (req, res) => {
  try {
    const courseCode = String(req.body.courseCode || '').trim().toUpperCase();
    const courseName = String(req.body.courseName || '').trim();
    const instructor = String(req.body.instructor || '').trim() || null;
    const credits = req.body.credits === '' || req.body.credits == null ? 3 : Number(req.body.credits);
    const description = String(req.body.description || '').trim() || null;

    const errors = validateCourse({ courseCode, courseName, instructor, credits });
    if (errors.length > 0) {
      return res.status(400).json({ success: false, message: 'Validation failed.', errors });
    }

    const [existing] = await pool.execute('SELECT id FROM courses WHERE course_code = ?', [courseCode]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, code: 'COURSE_EXISTS', message: `Course code "${courseCode}" already exists.` });
    }

    const [result] = await pool.execute(
      'INSERT INTO courses (course_code, course_name, instructor, credits, description, created_by) VALUES (?, ?, ?, ?, ?, ?)',
      [courseCode, courseName, instructor, credits, description, req.user.id]
    );

    const [rows] = await pool.execute('SELECT * FROM courses WHERE id = ?', [result.insertId]);
    return res.status(201).json({ success: true, message: 'Course added successfully.', course: publicCourse(rows[0]) });
  } catch (err) {
    console.error('Add course error:', err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ success: false, code: 'COURSE_EXISTS', message: 'A course with this code already exists.' });
    }
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// ── PUT /api/courses/:id — update a course (admin only) ────────────────
router.put('/:id', authorizeRole('admin'), async (req, res) => {
  try {
    const courseCode = String(req.body.courseCode || '').trim().toUpperCase();
    const courseName = String(req.body.courseName || '').trim();
    const instructor = String(req.body.instructor || '').trim() || null;
    const credits = req.body.credits === '' || req.body.credits == null ? 3 : Number(req.body.credits);
    const description = String(req.body.description || '').trim() || null;

    const errors = validateCourse({ courseCode, courseName, instructor, credits });
    if (errors.length > 0) {
      return res.status(400).json({ success: false, message: 'Validation failed.', errors });
    }

    const [existing] = await pool.execute('SELECT id FROM courses WHERE id = ?', [req.params.id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'Course not found.' });
    }

    const [duplicate] = await pool.execute(
      'SELECT id FROM courses WHERE course_code = ? AND id != ?',
      [courseCode, req.params.id]
    );
    if (duplicate.length > 0) {
      return res.status(409).json({ success: false, code: 'COURSE_EXISTS', message: `Course code "${courseCode}" is already used by another course.` });
    }

    await pool.execute(
      'UPDATE courses SET course_code = ?, course_name = ?, instructor = ?, credits = ?, description = ? WHERE id = ?',
      [courseCode, courseName, instructor, credits, description, req.params.id]
    );

    const [rows] = await pool.execute('SELECT * FROM courses WHERE id = ?', [req.params.id]);
    return res.json({ success: true, message: 'Course updated successfully.', course: publicCourse(rows[0]) });
  } catch (err) {
    console.error('Update course error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// ── DELETE /api/courses/:id — delete a course (admin only) ─────────────
router.delete('/:id', authorizeRole('admin'), async (req, res) => {
  try {
    const [result] = await pool.execute('DELETE FROM courses WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Course not found.' });
    }
    return res.json({ success: true, message: 'Course deleted successfully.' });
  } catch (err) {
    console.error('Delete course error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

module.exports = router;
