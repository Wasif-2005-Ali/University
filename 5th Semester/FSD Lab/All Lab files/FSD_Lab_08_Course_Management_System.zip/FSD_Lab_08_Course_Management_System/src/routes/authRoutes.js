/**
 * Auth routes — registration, login and "who am I".
 *
 *  POST /api/auth/register  (public)  Req. 2, 3, 4, 5
 *  POST /api/auth/login     (public)  Req. 6, 7
 *  GET  /api/auth/me        (protected) — used by both dashboards
 *
 * Security notes:
 *  • Passwords are hashed with bcrypt (cost factor 10) before storage
 *    and are NEVER returned in any response (Req. 4).
 *  • The role is always forced to "student" here — the client cannot
 *    assign itself "admin" through public registration (Req. 5, 6 of
 *    the General Instructions). Admins are created only via the
 *    database seed / by an existing admin.
 *  • All queries are parameterised (Req. 4 of General Instructions).
 *  • Login failures return one generic message so an attacker cannot
 *    tell whether the email or the password was wrong.
 */
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { validateRegistration, isValidEmail } = require('../utils/validation');

const router = express.Router();
const SALT_ROUNDS = 10;

/** Remove sensitive fields before sending a user object to the client. */
function publicUser(row) {
  return {
    id: row.id,
    fullName: row.full_name,
    email: row.email,
    role: row.role,
    createdAt: row.created_at,
  };
}

// ── POST /api/auth/register ────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const { password } = req.body;

    // 1. Backend validation (Req. 3)
    const errors = validateRegistration({ fullName, email, password });
    if (errors.length > 0) {
      return res.status(400).json({ success: false, message: 'Validation failed.', errors });
    }

    // 2. Prevent duplicate email addresses (Req. 3)
    const [existing] = await pool.execute('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({
        success: false,
        code: 'EMAIL_EXISTS',
        message: 'An account with this email already exists. Please log in instead.',
      });
    }

    // 3. Hash the password with bcrypt (Req. 4) — plain text never stored.
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    // 4. Default role is ALWAYS "student" (Req. 5). Any "role" sent by the
    //    client is deliberately ignored.
    const [result] = await pool.execute(
      'INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [fullName, email, passwordHash, 'student']
    );

    return res.status(201).json({
      success: true,
      message: 'Registration successful. You can now log in.',
      user: { id: result.insertId, fullName, email, role: 'student' },
    });
  } catch (err) {
    console.error('Register error:', err);
    // ER_DUP_ENTRY is a second safety net if two requests race the check above.
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({
        success: false,
        code: 'EMAIL_EXISTS',
        message: 'An account with this email already exists. Please log in instead.',
      });
    }
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// ── POST /api/auth/login ───────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const { password } = req.body;

    if (!isValidEmail(email) || typeof password !== 'string' || password.length === 0) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    // Verify credentials against the database (Req. 6)
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ success: false, code: 'INVALID_CREDENTIALS', message: 'Invalid email or password.' });
    }

    const user = rows[0];
    const passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) {
      return res.status(401).json({ success: false, code: 'INVALID_CREDENTIALS', message: 'Invalid email or password.' });
    }

    // Generate a JWT (Req. 7). Payload is minimal: id, email, role.
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '1h' }
    );

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: publicUser(user),
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

// ── GET /api/auth/me ───────────────────────────────────────────────────
// Lets a dashboard confirm the token is still valid and fetch the
// logged-in user's fresh details (name, email, role) from the database.
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, full_name, email, role, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }
    return res.json({ success: true, user: publicUser(rows[0]) });
  } catch (err) {
    console.error('Me error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

module.exports = router;
