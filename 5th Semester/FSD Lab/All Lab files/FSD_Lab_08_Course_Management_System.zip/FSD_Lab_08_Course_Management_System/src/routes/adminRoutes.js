/**
 * Admin-only routes (Req. 12, 14).
 * Both endpoints require a valid JWT AND the admin role.
 *
 *  GET /api/admin/stats  — counts for the admin dashboard cards
 *  GET /api/admin/users  — registered users (password hashes never returned)
 */
const express = require('express');
const { pool } = require('../config/db');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

const router = express.Router();

// Every route in this file: authenticated + admin only.
router.use(authenticateToken, authorizeRole('admin'));

router.get('/stats', async (req, res) => {
  try {
    const [[courseRow]] = await pool.execute('SELECT COUNT(*) AS total FROM courses');
    const [[studentRow]] = await pool.execute("SELECT COUNT(*) AS total FROM users WHERE role = 'student'");
    const [[adminRow]] = await pool.execute("SELECT COUNT(*) AS total FROM users WHERE role = 'admin'");
    return res.json({
      success: true,
      stats: {
        totalCourses: courseRow.total,
        totalStudents: studentRow.total,
        totalAdmins: adminRow.total,
      },
    });
  } catch (err) {
    console.error('Admin stats error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

router.get('/users', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, full_name, email, role, created_at FROM users ORDER BY created_at DESC'
    );
    return res.json({
      success: true,
      count: rows.length,
      users: rows.map((u) => ({
        id: u.id,
        fullName: u.full_name,
        email: u.email,
        role: u.role,
        createdAt: u.created_at,
      })),
    });
  } catch (err) {
    console.error('Admin users error:', err);
    return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
  }
});

module.exports = router;
