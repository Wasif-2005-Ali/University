/**
 * MySQL connection pool (mysql2/promise).
 *
 * Uses XAMPP defaults (host localhost, user root, no password) unless
 * overridden in the .env file. All queries in this project go through
 * this pool and use parameterised placeholders ("?") — never string
 * concatenation — so user input can never alter the SQL structure.
 */
const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'UniversityDB',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

/**
 * Verify the database is reachable at startup so a mis-configured
 * XAMPP/MySQL shows a clear error instead of failing on first request.
 */
async function testConnection() {
  const connection = await pool.getConnection();
  try {
    await connection.ping();
    console.log('✅ Connected to MySQL database "%s"', process.env.DB_NAME || 'UniversityDB');
  } finally {
    connection.release();
  }
}

module.exports = { pool, testConnection };
