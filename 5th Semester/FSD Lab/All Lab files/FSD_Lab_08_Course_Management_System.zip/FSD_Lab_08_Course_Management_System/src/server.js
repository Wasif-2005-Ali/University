/**
 * University Course Management System — server entry point.
 *
 * Full Stack Development Lab 08 (CS-301L)
 * Stack: Node.js + Express.js + MySQL (XAMPP) + jQuery frontend,
 *        bcrypt password hashing + JWT authentication + role-based auth.
 *
 *  Run:  npm install  →  copy .env.example to .env  →  npm start
 *  Open: http://localhost:3000
 */
require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');

const { testConnection } = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const courseRoutes = require('./routes/courseRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Safety check: the app must not run with a missing JWT secret ───────
if (!process.env.JWT_SECRET) {
  console.error('❌ FATAL: JWT_SECRET is not set. Copy .env.example to .env and set a secret value.');
  process.exit(1);
}

// ── Middleware ─────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── API routes ─────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/admin', adminRoutes);

// Health check — confirms the server is up AND the database is reachable.
app.get('/api/health', async (req, res) => {
  try {
    const { pool } = require('./config/db');
    await pool.query('SELECT 1');
    res.json({ success: true, message: 'University Course Management System API is running.', database: 'connected' });
  } catch (err) {
    res.status(503).json({ success: false, message: 'API is running but the database is unreachable.', database: 'disconnected' });
  }
});

// ── Frontend (static files in /public) ─────────────────────────────────
app.use(express.static(path.join(__dirname, '..', 'public')));

// Any unknown API route → JSON 404 (not an HTML page).
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, message: 'API endpoint not found.' });
});

// ── Central error handler ──────────────────────────────────────────────
 // eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
});

// ── Start ──────────────────────────────────────────────────────────────
async function start() {
  try {
    await testConnection();
  } catch (err) {
    console.error('❌ Could not connect to MySQL. Is XAMPP MySQL running?');
    console.error('   Check DB_HOST / DB_USER / DB_PASSWORD / DB_NAME in your .env file,');
    console.error('   and make sure you imported database/schema.sql (see README.md).');
    console.error('   Details:', err.message);
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
    console.log('   Student dashboard: http://localhost:%d/student-dashboard.html', PORT);
    console.log('   Admin dashboard:   http://localhost:%d/admin-dashboard.html', PORT);
  });
}

start();
