/**
 * Authentication & authorisation middleware.
 *
 *  authenticateToken — Req. 10: protects APIs from unauthenticated requests.
 *  authorizeRole     — Req. 11: role-based access (admin vs student).
 *
 * Token handling (Req. 16):
 *  • No token at all            → 401 { code: "NO_TOKEN" }
 *  • Expired token              → 401 { code: "TOKEN_EXPIRED" }
 *  • Tampered / malformed token → 401 { code: "INVALID_TOKEN" }
 *  • Valid token, wrong role    → 403 { code: "FORBIDDEN" }
 *
 * The frontend (public/js/common.js) reacts to 401 by clearing the stored
 * token and sending the user back to the login page with a message.
 */
const jwt = require('jsonwebtoken');

function authenticateToken(req, res, next) {
  // Expected format:  Authorization: Bearer <jwt>
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({
      success: false,
      code: 'NO_TOKEN',
      message: 'Access denied. No authentication token provided. Please log in.',
    });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({
          success: false,
          code: 'TOKEN_EXPIRED',
          message: 'Your session has expired. Please log in again.',
        });
      }
      return res.status(401).json({
        success: false,
        code: 'INVALID_TOKEN',
        message: 'Invalid authentication token. Please log in again.',
      });
    }

    // Payload was signed at login: { id, email, role }
    req.user = { id: decoded.id, email: decoded.email, role: decoded.role };
    next();
  });
}

/**
 * Usage:  router.post('/courses', authenticateToken, authorizeRole('admin'), ...)
 * Any authenticated user whose role is not in the allowed list is rejected.
 */
function authorizeRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        code: 'NO_TOKEN',
        message: 'Access denied. No authentication token provided. Please log in.',
      });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        code: 'FORBIDDEN',
        message: `Access denied. This operation requires the "${allowedRoles.join(' / ')}" role.`,
      });
    }
    next();
  };
}

module.exports = { authenticateToken, authorizeRole };
