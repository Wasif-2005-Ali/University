/**
 * Server-side validation helpers (Req. 3).
 * Frontend validation exists too, but the backend is the authority —
 * it must never trust what the client sends.
 */

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Full name: at least 3 characters, letters/spaces/hyphens/apostrophes. */
function isValidFullName(name) {
  return (
    typeof name === 'string' &&
    name.trim().length >= 3 &&
    name.trim().length <= 100 &&
    /^[A-Za-z\s.'-]+$/.test(name.trim())
  );
}

function isValidEmail(email) {
  return typeof email === 'string' && EMAIL_REGEX.test(email.trim().toLowerCase());
}

/** Password: at least 8 characters, must contain a letter and a number. */
function isValidPassword(password) {
  return (
    typeof password === 'string' &&
    password.length >= 8 &&
    /[A-Za-z]/.test(password) &&
    /[0-9]/.test(password)
  );
}

/**
 * Validate registration input. Returns an array of error messages
 * (empty when everything is valid).
 */
function validateRegistration({ fullName, email, password }) {
  const errors = [];
  if (!isValidFullName(fullName)) {
    errors.push('Full name must be at least 3 characters long and contain only letters, spaces, hyphens or apostrophes.');
  }
  if (!isValidEmail(email)) {
    errors.push('Please provide a valid email address.');
  }
  if (!isValidPassword(password)) {
    errors.push('Password must be at least 8 characters long and contain at least one letter and one number.');
  }
  return errors;
}

/** Validate course input for create/update. Returns error messages array. */
function validateCourse({ courseCode, courseName, instructor, credits }) {
  const errors = [];
  if (!courseCode || !/^[A-Za-z]{2,5}-?\d{3,4}$/.test(String(courseCode).trim())) {
    errors.push('Course code is required (e.g. CS-301).');
  }
  if (!courseName || String(courseName).trim().length < 3 || String(courseName).trim().length > 150) {
    errors.push('Course name must be between 3 and 150 characters.');
  }
  if (instructor !== undefined && instructor !== null && String(instructor).trim().length > 100) {
    errors.push('Instructor name must be 100 characters or fewer.');
  }
  const creditsNum = Number(credits);
  if (credits !== undefined && credits !== null && credits !== '' && (!Number.isInteger(creditsNum) || creditsNum < 1 || creditsNum > 6)) {
    errors.push('Credits must be a whole number between 1 and 6.');
  }
  return errors;
}

module.exports = { isValidFullName, isValidEmail, isValidPassword, validateRegistration, validateCourse };
