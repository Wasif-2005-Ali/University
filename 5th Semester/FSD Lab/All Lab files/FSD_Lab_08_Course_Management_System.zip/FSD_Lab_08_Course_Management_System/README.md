# University Course Management System

**Full Stack Development — Lab 08 (CS-301L)**
Air University Islamabad, Kamra Campus · BSCS-VB · Teacher: M. Fahad Qasim
Student: Wasif Ali

A web-based Course Management System where students can register, log in and
view available courses, while administrators manage course information.
Only authenticated users can access protected resources, and every operation
is checked against the user's assigned role — on the backend.

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | HTML, CSS, jQuery 3.7.1 (AJAX) — no build step |
| Backend | Node.js + Express.js |
| Database | MySQL via XAMPP (`UniversityDB`) |
| Auth | bcrypt password hashing + JSON Web Tokens (JWT) |

## Features

- **Registration** — full name, email, password; backend validation, duplicate
  email rejected, passwords hashed with bcrypt, new users are always `student`.
- **Login** — credentials verified against the database; a JWT is issued and
  stored in `localStorage`, then sent as `Authorization: Bearer <token>` on
  every protected request.
- **Student Dashboard** — shows the logged-in student's name, email, role and
  all available courses (with search).
- **Admin Dashboard** — admins only: statistics, full course CRUD
  (add / view / update / delete) and a registered-users table.
- **Role-based authorization** — students get `403 Forbidden` from admin APIs;
  the check is enforced by backend middleware, not just by hiding buttons.
- **Logout** — clears the stored token and user session.
- **Error handling** — missing token, expired token, invalid token, invalid
  credentials and unauthorized access each return a clear, distinct response.

## Project structure

```
FSD_Lab_08_Course_Management_System/
├── database/
│   └── schema.sql            # UniversityDB: users + courses tables + seed data
├── docs/
│   └── TESTING.md            # Full test plan: every requirement, step by step
├── public/                   # Served statically by Express
│   ├── index.html            # Landing page
│   ├── login.html            # Login interface
│   ├── register.html         # Registration interface
│   ├── student-dashboard.html
│   ├── admin-dashboard.html
│   ├── css/style.css
│   └── js/
│       ├── vendor/jquery-3.7.1.min.js
│       ├── common.js         # Auth helpers, token storage, apiRequest(), logout
│       ├── auth.js           # Login / registration (jQuery AJAX)
│       ├── student.js        # Student dashboard
│       └── admin.js          # Admin dashboard + course CRUD
├── src/
│   ├── server.js             # Entry point, route mounting, error handler
│   ├── config/db.js          # MySQL connection pool (mysql2/promise)
│   ├── middleware/auth.js    # authenticateToken + authorizeRole('admin')
│   ├── routes/
│   │   ├── authRoutes.js     # POST /api/auth/register, /login; GET /api/auth/me
│   │   ├── courseRoutes.js   # GET /api/courses[/:id]; POST/PUT/DELETE (admin)
│   │   └── adminRoutes.js    # GET /api/admin/stats, /api/admin/users
│   └── utils/validation.js   # Backend validation (registration + courses)
├── .env.example              # Copy to .env and set your own JWT_SECRET
├── .gitignore
└── package.json
```

## Setup (Windows + XAMPP)

### 1. Start MySQL

Open the **XAMPP Control Panel** and start **Apache** and **MySQL**.

### 2. Create the database

Open phpMyAdmin at http://localhost/phpmyadmin → **Import** → choose
`database/schema.sql` → **Go**.

Or from a terminal (from the project folder):

```bash
mysql -u root < database/schema.sql
```

This creates `UniversityDB` with `users` and `courses` tables, plus demo
accounts and 6 sample courses. Re-importing the file is safe.

### 3. Install dependencies

```bash
npm install
```

### 4. Configure the environment

```bash
copy .env.example .env
```

Then open `.env` and set a long random `JWT_SECRET`. The XAMPP defaults
(`DB_USER=root`, empty `DB_PASSWORD`, `DB_NAME=UniversityDB`) already match
a standard XAMPP install. **Never commit a real `.env` file.**

### 5. Run the server

```bash
npm start
```

Open http://localhost:3000 — you will land on the home page, with links to login and registration.

## Demo accounts (seeded by `database/schema.sql`)

| Role | Email | Password |
|---|---|---|
| Admin | `admin@au.edu.pk` | `Admin@123` |
| Student | `student@au.edu.pk` | `Student@123` |

You can also register a brand-new student at `/register.html` — new
registrations are always created as `student`; there is no way to register
as an admin from the public form.

## API reference

All `/api/*` routes except register/login return JSON
`{ success, message, ... }`. Protected routes require the header
`Authorization: Bearer <jwt>`.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register a student (validated, bcrypt-hashed) |
| POST | `/api/auth/login` | Public | Log in, receive a JWT (1 hour) |
| GET | `/api/auth/me` | Logged in | Current user's profile |
| GET | `/api/courses` | Logged in | List courses (`?search=` filters) |
| GET | `/api/courses/:id` | Logged in | One course |
| POST | `/api/courses` | Admin | Add a course |
| PUT | `/api/courses/:id` | Admin | Update a course |
| DELETE | `/api/courses/:id` | Admin | Delete a course |
| GET | `/api/admin/stats` | Admin | Course / student / admin counts |
| GET | `/api/admin/users` | Admin | Registered users (no password hashes) |
| GET | `/api/health` | Public | Server + database status check |

### Auth error codes

| Situation | Response |
|---|---|
| No token | `401 { code: "NO_TOKEN" }` |
| Expired token | `401 { code: "TOKEN_EXPIRED" }` |
| Invalid / tampered token | `401 { code: "INVALID_TOKEN" }` |
| Wrong email or password | `401 { code: "INVALID_CREDENTIALS" }` |
| Email already registered | `409 { code: "EMAIL_EXISTS" }` |
| Valid token, wrong role (e.g. student calling an admin API) | `403 { code: "FORBIDDEN" }` |

On a `401` the frontend clears the stored token and returns the user to
the login page with an explanation.

## How the lab requirements are covered

| # | Requirement | Where it is implemented |
|---|---|---|
| 1 | Database `UniversityDB` with `users` and `courses` tables | `database/schema.sql` |
| 2 | Registration interface (full name, email, password) | `public/register.html`, `public/js/auth.js` |
| 3 | Backend validation + duplicate-email prevention | `src/utils/validation.js`, `src/routes/authRoutes.js` (400 / 409) |
| 4 | bcrypt password hashing | `src/routes/authRoutes.js` (`bcrypt.hash`, cost 10) |
| 5 | Default role `student` for new users | `src/routes/authRoutes.js` — role is forced, client input ignored |
| 6 | Login interface, credentials verified vs database | `public/login.html`, `src/routes/authRoutes.js` |
| 7 | JWT generated after successful login | `src/routes/authRoutes.js` (`jsonwebtoken`, 1 h expiry) |
| 8 | Token stored client-side, sent on protected requests | `public/js/common.js` (`localStorage`, `Authorization: Bearer`) |
| 9 | Student Dashboard: name, email, available courses | `public/student-dashboard.html`, `public/js/student.js` |
| 10 | Authentication middleware protecting APIs | `src/middleware/auth.js` (`authenticateToken`) |
| 11 | Role-based authorization middleware (admin vs student) | `src/middleware/auth.js` (`authorizeRole`) |
| 12 | Admin Dashboard for authenticated admins only | `public/admin-dashboard.html`, `public/js/admin.js` |
| 13 | Admin add / view / update / delete courses | `src/routes/courseRoutes.js`, `public/js/admin.js` |
| 14 | Students blocked from admin APIs and operations | `authorizeRole('admin')` on write routes + `/api/admin/*` (403) |
| 15 | Logout removes stored authentication info | `public/js/common.js` (`Auth.logout()` clears `localStorage`) |
| 16 | Invalid credentials / missing / unauthorized / expired-token handling | `src/middleware/auth.js`, `src/routes/authRoutes.js`, `public/js/common.js` |

General instructions are also followed: jQuery AJAX throughout, code split
into `src/` and `public/` folders, all auth checks on the backend, only
parameterised SQL queries (`?` placeholders via `mysql2/promise`), no
plain-text passwords, and no self-assigned admin role.

## Quick test checklist

1. Register a new student → log in → Student Dashboard shows your name,
   email and the 6 sample courses.
2. Log in as `admin@au.edu.pk` / `Admin@123` → Admin Dashboard → add, edit
   and delete a course; the new course appears on the Student Dashboard.
3. As a student, open the browser console and try
   `fetch('/api/admin/users', { headers: { Authorization: 'Bearer ' + localStorage.getItem('cms_token') } })`
   → expect `403 FORBIDDEN`.
4. Register with an email that already exists → expect `409 EMAIL_EXISTS`.
5. Log in with a wrong password → expect `401 INVALID_CREDENTIALS`.
6. Open `/student-dashboard.html` in a private window without logging in →
   redirected to the login page.
7. Log out → the token is removed and protected pages redirect to login.

## Notes

- The JWT secret lives only in `.env` (see `.env.example`); the server
  refuses to start without it.
- `node_modules/` is not part of the submission — run `npm install` after
  unzipping (see `.gitignore`).
