/**
 * Shared frontend helpers — jQuery + localStorage JWT handling.
 *
 * Token storage (Req. 8): the JWT returned at login is stored in
 * localStorage under "cms_token" (with the user profile under
 * "cms_user") and sent as `Authorization: Bearer <token>` on every
 * protected API call via apiRequest().
 *
 * Error handling (Req. 16): a 401 (missing / expired / invalid token)
 * clears the stored token and redirects to login with an explanation;
 * a 403 shows an "access denied" message instead of silently failing.
 */
(function (global, $) {
  'use strict';

  var TOKEN_KEY = 'cms_token';
  var USER_KEY = 'cms_user';

  var Auth = {
    getToken: function () { return localStorage.getItem(TOKEN_KEY); },
    setSession: function (token, user) {
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    },
    getUser: function () {
      try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); }
      catch (e) { return null; }
    },
    isLoggedIn: function () { return !!this.getToken(); },
    clearSession: function () {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    },
    // Req. 15 — logout removes all stored authentication information.
    logout: function (message) {
      this.clearSession();
      var url = 'login.html';
      if (message) url += '?msg=' + encodeURIComponent(message);
      window.location.href = url;
    },
    dashboardUrlFor: function (user) {
      return user && user.role === 'admin' ? 'admin-dashboard.html' : 'student-dashboard.html';
    }
  };

  /**
   * Route guard for protected pages. Call at the top of a dashboard script:
   *   Auth.requireAuth();            — any logged-in user
   *   Auth.requireAuth('admin');     — admins only (students are sent away)
   * Returns the stored user, or null after redirecting.
   */
  Auth.requireAuth = function (requiredRole) {
    var user = this.getUser();
    if (!this.getToken() || !user) {
      window.location.href = 'login.html?msg=' + encodeURIComponent('Please log in to continue.');
      return null;
    }
    if (requiredRole && user.role !== requiredRole) {
      // Students must never land on the admin dashboard (Req. 12, 14).
      // The backend enforces this too — this is only the friendly redirect.
      window.location.href = this.dashboardUrlFor(user) +
        '?msg=' + encodeURIComponent('Access denied. That page is for administrators only.');
      return null;
    }
    return user;
  };

  /**
   * jQuery AJAX wrapper for API calls. Automatically attaches the JWT
   * and handles auth failures globally. Returns a jqXHR (Promise-like).
   */
  function apiRequest(options) {
    var headers = {};
    var token = Auth.getToken();
    if (token) headers.Authorization = 'Bearer ' + token;

    return $.ajax({
      url: options.url,
      method: options.method || 'GET',
      data: options.data ? JSON.stringify(options.data) : undefined,
      contentType: 'application/json',
      dataType: 'json',
      headers: headers
    }).fail(function (jqXHR) {
      if (jqXHR.status === 401) {
        var msg = 'Your session has expired. Please log in again.';
        try {
          var body = JSON.parse(jqXHR.responseText);
          if (body && body.message) msg = body.message;
        } catch (e) { /* keep default message */ }
        Auth.logout(msg);
      }
    });
  }

  /** Extract a readable message (+ validation errors) from an API failure. */
  function apiErrorMessage(jqXHR, fallback) {
    try {
      var body = JSON.parse(jqXHR.responseText);
      if (body) {
        if (body.errors && body.errors.length) return body.message + ' ' + body.errors.join(' ');
        if (body.message) return body.message;
      }
    } catch (e) { /* fall through */ }
    return fallback || 'Something went wrong. Please try again.';
  }

  /** Show / hide the inline alert boxes used on every page. */
  function showAlert(selector, message) {
    if (!message) { $(selector).removeClass('show').empty(); return; }
    $(selector).html(message).addClass('show');
  }
  function hideAlerts() { $('.alert').removeClass('show').empty(); }

  /** Small toast notification, bottom-right. type: 'success' | 'error' | ''. */
  var toastTimer = null;
  function showToast(message, type) {
    var $toast = $('#toast');
    $toast.text(message).removeClass('success error').addClass('show ' + (type || ''));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.removeClass('show'); }, 3500);
  }

  /** Escape text before injecting into HTML (prevents stored XSS). */
  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function formatDate(value) {
    if (!value) return '—';
    var d = new Date(value);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  function queryParam(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  // Logout links exist on every protected page.
  $(document).on('click', '#logoutLink', function (e) {
    e.preventDefault();
    Auth.logout('You have been logged out.');
  });

  global.Auth = Auth;
  global.apiRequest = apiRequest;
  global.apiErrorMessage = apiErrorMessage;
  global.showAlert = showAlert;
  global.hideAlerts = hideAlerts;
  global.showToast = showToast;
  global.escapeHtml = escapeHtml;
  global.formatDate = formatDate;
  global.queryParam = queryParam;
})(window, jQuery);
