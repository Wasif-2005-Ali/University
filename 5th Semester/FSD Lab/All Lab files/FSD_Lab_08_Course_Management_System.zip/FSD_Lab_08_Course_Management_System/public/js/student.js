/**
 * Student Dashboard — protected page (Req. 9).
 * Loads the logged-in student's profile (GET /api/auth/me) and the
 * available courses (GET /api/courses), both with the stored JWT.
 */
$(function () {
  'use strict';

  var user = Auth.requireAuth(); // any authenticated user
  if (!user) return;

  var msg = queryParam('msg');
  if (msg) showToast(msg, 'error');

  // ── Profile ──────────────────────────────────────────────────────────
  function renderProfile(u) {
    $('#studentName').text(u.fullName);
    $('#studentEmail').text(u.email);
    $('#studentRole').text(u.role).removeClass('badge-student badge-admin')
      .addClass(u.role === 'admin' ? 'badge-admin' : 'badge-student');
    var initials = u.fullName.split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
    $('#avatarInitials').text(initials || '?');
  }
  renderProfile(user); // instant, from stored session

  // Refresh from the server (confirms the token is still valid).
  apiRequest({ url: '/api/auth/me' })
    .done(function (res) { renderProfile(res.user); })
    .fail(function (jqXHR) {
      if (jqXHR.status !== 401) showAlert('#errorAlert', 'Could not load your profile. Please refresh the page.');
    });

  // ── Courses ──────────────────────────────────────────────────────────
  function loadCourses(search) {
    $('#coursesContainer').html('<p class="spinner">Loading courses…</p>');
    var url = '/api/courses' + (search ? '?search=' + encodeURIComponent(search) : '');
    apiRequest({ url: url })
      .done(function (res) {
        $('#courseCount').text('(' + res.count + ' available)');
        if (!res.courses.length) {
          $('#coursesContainer').html('<p class="empty">No courses found. Try a different search.</p>');
          return;
        }
        var html = '<div class="course-grid">';
        res.courses.forEach(function (c) {
          html += '<article class="course-card">' +
            '<span class="course-code">' + escapeHtml(c.courseCode) + ' &bull; ' + escapeHtml(c.credits) + ' credit hours</span>' +
            '<h3>' + escapeHtml(c.courseName) + '</h3>' +
            '<p class="course-meta">Instructor: ' + escapeHtml(c.instructor || 'To be announced') + '</p>' +
            (c.description ? '<p class="course-desc">' + escapeHtml(c.description) + '</p>' : '') +
            '</article>';
        });
        html += '</div>';
        $('#coursesContainer').html(html);
      })
      .fail(function (jqXHR) {
        if (jqXHR.status !== 401) {
          $('#coursesContainer').html('<p class="empty">Could not load courses. Please refresh the page.</p>');
        }
      });
  }

  loadCourses('');

  $('#searchBtn').on('click', function () { loadCourses($('#searchInput').val().trim()); });
  $('#searchInput').on('keyup', function (e) { if (e.key === 'Enter') loadCourses($(this).val().trim()); });
});
