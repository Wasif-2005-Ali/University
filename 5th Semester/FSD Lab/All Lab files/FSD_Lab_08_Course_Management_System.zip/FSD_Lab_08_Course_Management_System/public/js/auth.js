/**
 * Login & registration pages — jQuery AJAX to /api/auth/*.
 *
 * On successful login the JWT + user profile are stored via Auth.setSession
 * (localStorage) and the user is redirected to the dashboard matching
 * their role: admins → admin-dashboard.html, students → student-dashboard.html.
 */
$(function () {
  'use strict';

  // If already logged in, skip the auth pages entirely.
  if (Auth.isLoggedIn() && Auth.getUser()) {
    window.location.href = Auth.dashboardUrlFor(Auth.getUser());
    return;
  }

  // Message passed via redirect (e.g. after logout / session expiry).
  var msg = queryParam('msg');
  if (msg) showAlert('#infoAlert', escapeHtml(msg));

  function setLoading($btn, loading, label) {
    $btn.prop('disabled', loading).text(loading ? 'Please wait…' : label);
  }

  // ── Login ────────────────────────────────────────────────────────────
  $('#loginForm').on('submit', function (e) {
    e.preventDefault();
    hideAlerts();

    var email = $('#email').val().trim();
    var password = $('#password').val();
    if (!email || !password) {
      showAlert('#errorAlert', 'Please enter your email and password.');
      return;
    }

    var $btn = $('#loginBtn');
    setLoading($btn, true, 'Log In');

    $.ajax({
      url: '/api/auth/login',
      method: 'POST',
      contentType: 'application/json',
      dataType: 'json',
      data: JSON.stringify({ email: email, password: password })
    })
      .done(function (res) {
        Auth.setSession(res.token, res.user); // Req. 8: store token client-side
        showToast('Welcome back, ' + res.user.fullName + '!', 'success');
        setTimeout(function () { window.location.href = Auth.dashboardUrlFor(res.user); }, 400);
      })
      .fail(function (jqXHR) {
        showAlert('#errorAlert', escapeHtml(apiErrorMessage(jqXHR, 'Login failed. Please try again.')));
        setLoading($btn, false, 'Log In');
      });
  });

  // ── Registration ─────────────────────────────────────────────────────
  $('#registerForm').on('submit', function (e) {
    e.preventDefault();
    hideAlerts();

    var fullName = $('#fullName').val().trim();
    var email = $('#email').val().trim();
    var password = $('#password').val();
    var confirmPassword = $('#confirmPassword').val();

    // Light client-side checks (the backend re-validates everything).
    var errors = [];
    if (fullName.length < 3) errors.push('Full name must be at least 3 characters long.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.push('Please enter a valid email address.');
    if (password.length < 8 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
      errors.push('Password must be at least 8 characters and contain a letter and a number.');
    }
    if (password !== confirmPassword) errors.push('Passwords do not match.');
    if (errors.length) {
      showAlert('#errorAlert', '<strong>Please fix the following:</strong><ul><li>' + errors.join('</li><li>') + '</li></ul>');
      return;
    }

    var $btn = $('#registerBtn');
    setLoading($btn, true, 'Create Account');

    $.ajax({
      url: '/api/auth/register',
      method: 'POST',
      contentType: 'application/json',
      dataType: 'json',
      data: JSON.stringify({ fullName: fullName, email: email, password: password })
    })
      .done(function () {
        showAlert('#successAlert', 'Account created successfully! Redirecting to login…');
        $('#registerForm')[0].reset();
        setTimeout(function () { window.location.href = 'login.html?msg=' + encodeURIComponent('Registration successful. Please log in.'); }, 1200);
      })
      .fail(function (jqXHR) {
        showAlert('#errorAlert', escapeHtml(apiErrorMessage(jqXHR, 'Registration failed. Please try again.')));
        setLoading($btn, false, 'Create Account');
      });
  });
});
