/**
 * Admin Dashboard — admins only (Req. 12, 13, 14).
 * Frontend guard + backend authorizeRole('admin') on every write API.
 * Features: stats cards, course CRUD (add / edit / delete with modals),
 * course search, and a registered-users table.
 */
$(function () {
  'use strict';

  var user = Auth.requireAuth('admin');
  if (!user) return;

  var msg = queryParam('msg');
  if (msg) showToast(msg, 'error');

  $('#adminName').text(user.fullName);
  $('#adminEmail').text(user.email);

  var deleteTargetId = null;
  var deleteTargetName = '';

  // ── Tabs ─────────────────────────────────────────────────────────────
  $('.tab-btn').on('click', function () {
    $('.tab-btn').removeClass('active');
    $(this).addClass('active');
    $('.tab-panel').removeClass('active');
    $('#' + $(this).data('tab')).addClass('active');
  });

  // ── Stats ────────────────────────────────────────────────────────────
  function loadStats() {
    apiRequest({ url: '/api/admin/stats' })
      .done(function (res) {
        $('#statCourses').text(res.stats.totalCourses);
        $('#statStudents').text(res.stats.totalStudents);
        $('#statAdmins').text(res.stats.totalAdmins);
      });
  }

  // ── Courses table ────────────────────────────────────────────────────
  function loadCourses(search) {
    $('#coursesTableBody').html('<tr><td colspan="5" class="empty">Loading courses…</td></tr>');
    var url = '/api/courses' + (search ? '?search=' + encodeURIComponent(search) : '');
    apiRequest({ url: url })
      .done(function (res) {
        if (!res.courses.length) {
          $('#coursesTableBody').html('<tr><td colspan="5" class="empty">No courses found. Click “Add Course” to create one.</td></tr>');
          return;
        }
        var html = '';
        res.courses.forEach(function (c) {
          html += '<tr data-id="' + c.id + '">' +
            '<td><strong>' + escapeHtml(c.courseCode) + '</strong></td>' +
            '<td>' + escapeHtml(c.courseName) +
              (c.description ? '<br><span style="color: var(--muted); font-size: 13px;">' + escapeHtml(c.description) + '</span>' : '') + '</td>' +
            '<td>' + escapeHtml(c.instructor || '—') + '</td>' +
            '<td>' + escapeHtml(c.credits) + '</td>' +
            '<td class="actions">' +
              '<button class="btn btn-secondary btn-sm edit-btn">Edit</button>' +
              '<button class="btn btn-danger btn-sm delete-btn">Delete</button>' +
            '</td></tr>';
        });
        $('#coursesTableBody').html(html);
      })
      .fail(function (jqXHR) {
        if (jqXHR.status !== 401) {
          $('#coursesTableBody').html('<tr><td colspan="5" class="empty">Could not load courses.</td></tr>');
        }
      });
  }

  // ── Users table ──────────────────────────────────────────────────────
  function loadUsers() {
    apiRequest({ url: '/api/admin/users' })
      .done(function (res) {
        if (!res.users.length) {
          $('#usersTableBody').html('<tr><td colspan="5" class="empty">No users registered yet.</td></tr>');
          return;
        }
        var html = '';
        res.users.forEach(function (u, i) {
          html += '<tr><td>' + (i + 1) + '</td>' +
            '<td>' + escapeHtml(u.fullName) + '</td>' +
            '<td>' + escapeHtml(u.email) + '</td>' +
            '<td><span class="badge ' + (u.role === 'admin' ? 'badge-admin' : 'badge-student') + '">' + escapeHtml(u.role) + '</span></td>' +
            '<td>' + formatDate(u.createdAt) + '</td></tr>';
        });
        $('#usersTableBody').html(html);
      })
      .fail(function () {
        $('#usersTableBody').html('<tr><td colspan="5" class="empty">Could not load users.</td></tr>');
      });
  }

  loadStats();
  loadCourses('');
  loadUsers();

  $('#searchBtn').on('click', function () { loadCourses($('#searchInput').val().trim()); });
  $('#searchInput').on('keyup', function (e) { if (e.key === 'Enter') loadCourses($(this).val().trim()); });

  // ── Add / Edit modal ─────────────────────────────────────────────────
  function openCourseModal(course) {
    hideAlerts();
    $('#modalError').removeClass('show').empty();
    if (course) {
      $('#modalTitle').text('Edit Course');
      $('#courseId').val(course.id);
      $('#courseCode').val(course.courseCode);
      $('#courseName').val(course.courseName);
      $('#instructor').val(course.instructor || '');
      $('#credits').val(course.credits);
      $('#description').val(course.description || '');
    } else {
      $('#modalTitle').text('Add Course');
      $('#courseForm')[0].reset();
      $('#courseId').val('');
      $('#credits').val(3);
    }
    $('#courseModal').addClass('open');
    $('#courseCode').focus();
  }
  function closeCourseModal() { $('#courseModal').removeClass('open'); }

  $('#addCourseBtn').on('click', function () { openCourseModal(null); });
  $('#cancelCourseBtn').on('click', closeCourseModal);
  $('#courseModal').on('click', function (e) { if (e.target === this) closeCourseModal(); });

  // Edit: fetch the fresh course record, then open the modal.
  $('#coursesTableBody').on('click', '.edit-btn', function () {
    var id = $(this).closest('tr').data('id');
    apiRequest({ url: '/api/courses/' + id })
      .done(function (res) { openCourseModal(res.course); })
      .fail(function (jqXHR) {
        showToast(apiErrorMessage(jqXHR, 'Could not load that course.'), 'error');
      });
  });

  $('#courseForm').on('submit', function (e) {
    e.preventDefault();
    $('#modalError').removeClass('show').empty();

    var id = $('#courseId').val();
    var payload = {
      courseCode: $('#courseCode').val().trim(),
      courseName: $('#courseName').val().trim(),
      instructor: $('#instructor').val().trim(),
      credits: $('#credits').val(),
      description: $('#description').val().trim()
    };
    if (!payload.courseCode || !payload.courseName) {
      showAlert('#modalError', 'Course code and course name are required.');
      return;
    }

    var $btn = $('#saveCourseBtn');
    $btn.prop('disabled', true).text('Saving…');

    apiRequest({
      url: id ? '/api/courses/' + id : '/api/courses',
      method: id ? 'PUT' : 'POST',
      data: payload
    })
      .done(function (res) {
        closeCourseModal();
        showToast(res.message, 'success');
        loadCourses($('#searchInput').val().trim());
        loadStats();
      })
      .fail(function (jqXHR) {
        if (jqXHR.status !== 401) {
          showAlert('#modalError', escapeHtml(apiErrorMessage(jqXHR, 'Could not save the course.')));
        }
      })
      .always(function () { $btn.prop('disabled', false).text('Save Course'); });
  });

  // ── Delete (with confirmation) ───────────────────────────────────────
  $('#coursesTableBody').on('click', '.delete-btn', function () {
    var $row = $(this).closest('tr');
    deleteTargetId = $row.data('id');
    deleteTargetName = $row.find('td:nth-child(2)').text().trim();
    $('#deleteText').text('Are you sure you want to delete "' + deleteTargetName + '"? This cannot be undone.');
    $('#deleteModal').addClass('open');
  });
  $('#cancelDeleteBtn').on('click', function () { $('#deleteModal').removeClass('open'); });
  $('#deleteModal').on('click', function (e) { if (e.target === this) $(this).removeClass('open'); });

  $('#confirmDeleteBtn').on('click', function () {
    if (!deleteTargetId) return;
    var $btn = $(this);
    $btn.prop('disabled', true).text('Deleting…');
    apiRequest({ url: '/api/courses/' + deleteTargetId, method: 'DELETE' })
      .done(function (res) {
        $('#deleteModal').removeClass('open');
        showToast(res.message, 'success');
        loadCourses($('#searchInput').val().trim());
        loadStats();
      })
      .fail(function (jqXHR) {
        if (jqXHR.status !== 401) showToast(apiErrorMessage(jqXHR, 'Could not delete the course.'), 'error');
      })
      .always(function () { $btn.prop('disabled', false).text('Delete'); });
  });

  // Close modals with the Escape key.
  $(document).on('keyup', function (e) {
    if (e.key === 'Escape') $('.modal-overlay').removeClass('open');
  });
});
