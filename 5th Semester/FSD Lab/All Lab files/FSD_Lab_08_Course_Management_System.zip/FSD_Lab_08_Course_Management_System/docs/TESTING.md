# Testing Guide — University Course Management System

Full Stack Development Lab 08 (CS-301L). Each test below maps to one or
more numbered requirements from the lab sheet. Run the server first
(`npm start`, http://localhost:3000) with XAMPP MySQL running and
`database/schema.sql` imported.

Demo accounts: **admin@au.edu.pk / Admin@123** (admin),
**student@au.edu.pk / Student@123** (student).

> Tip: after logging in through the browser, the JWT is visible in DevTools
> → Application → Local Storage → `cms_token`. Copy it for the curl tests
> as `TOKEN=<your token>`.

## 1. Registration (Req. 2, 3, 4, 5)

| # | Steps | Expected result |
|---|---|---|
| 1.1 | Open `/register.html`, enter a name, a new email and a password (8+ chars, letter + number), submit. | Success message, redirect to login. |
| 1.2 | Register again with the **same email**. | `409` — "An account with this email already exists." |
| 1.3 | Try an invalid email (`abc`), a short password (`123`) and a 2-letter name. | `400` with a clear list of validation errors. |
| 1.4 | In phpMyAdmin, open `users` and check the new row. | `role` is `student`; `password_hash` starts with `$2b$10$` (bcrypt) — no plain-text password anywhere. |
| 1.5 | Try to smuggle a role in: `curl -X POST localhost:3000/api/auth/register -H "Content-Type: application/json" -d '{"fullName":"Hacker","email":"hack@test.com","password":"Hacker123","role":"admin"}'` then check the row. | Account is created as `student` — the `role` field is ignored. |

## 2. Login + JWT (Req. 6, 7, 8)

| # | Steps | Expected result |
|---|---|---|
| 2.1 | Log in with correct credentials. | `200` with `token` and `user`; redirected to the dashboard matching the role. |
| 2.2 | Log in with a wrong password (or an unregistered email). | `401 INVALID_CREDENTIALS` — "Invalid email or password." (Same message either way.) |
| 2.3 | After login, open DevTools → Application → Local Storage. | `cms_token` (JWT) and `cms_user` are stored. |
| 2.4 | On the Student Dashboard, open DevTools → Network → click the `courses` request → Headers. | Request carries `Authorization: Bearer <token>`. |

## 3. Student Dashboard (Req. 9)

| # | Steps | Expected result |
|---|---|---|
| 3.1 | Log in as the demo student. | Dashboard shows "Demo Student", `student@au.edu.pk`, `STUDENT` badge and the 6 sample courses. |
| 3.2 | Search for `CS-301` / `Fahad` / `Data`. | The course list filters live. |
| 3.3 | Open `/student-dashboard.html` in a private/incognito window (not logged in). | Redirected to `login.html` with "Please log in to continue." |

## 4. Auth middleware (Req. 10, 16)

```bash
# No token at all
curl -s localhost:3000/api/courses
# → 401 { "code": "NO_TOKEN", ... }

# Garbage token
curl -s localhost:3000/api/courses -H "Authorization: Bearer not-a-real-token"
# → 401 { "code": "INVALID_TOKEN", ... }

# Expired token: set JWT_EXPIRES_IN=1s in .env, restart, log in, wait 2
# seconds, then call any protected route
# → 401 { "code": "TOKEN_EXPIRED", "message": "Your session has expired..." }
```

In the browser, a `401` clears the stored token and returns the user to
the login page with the explanation shown.

## 5. Admin Dashboard + course CRUD (Req. 12, 13)

| # | Steps | Expected result |
|---|---|---|
| 5.1 | Log in as `admin@au.edu.pk` / `Admin@123`. | Admin Dashboard with stat cards (courses, students, admins) and the course table + users table. |
| 5.2 | Click **+ Add Course**, fill in a new course, save. | Course appears in the table, in the stats count, and on the Student Dashboard. |
| 5.3 | Click **Edit** on a course, change its name/credits, save. | Row updates immediately. |
| 5.4 | Click **Delete**, confirm. | Course is removed after the confirmation dialog. |
| 5.5 | Try adding a course with a code that already exists (e.g. `CS-301`). | `409 COURSE_EXISTS`. |

## 6. Role-based authorization (Req. 11, 14)

Log in as a **student**, then in the browser console (or curl with the
student's token):

```js
// Student calling admin-only endpoints — all must fail with 403:
fetch('/api/admin/users',  { headers: { Authorization: 'Bearer ' + localStorage.getItem('cms_token') } }).then(r => r.json()).then(console.log);
// → 403 { "code": "FORBIDDEN", ... }

fetch('/api/courses', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + localStorage.getItem('cms_token') },
  body: JSON.stringify({ courseCode: 'CS-999', courseName: 'Hacked Course' }) }).then(r => r.json()).then(console.log);
// → 403 { "code": "FORBIDDEN", ... }
```

Also try opening `/admin-dashboard.html` directly as a student — the page
redirects back to the Student Dashboard with an "administrators only"
message. (The redirect is only for UX; the backend `403` is the real
protection, as proven above.)

## 7. Logout (Req. 15)

| # | Steps | Expected result |
|---|---|---|
| 7.1 | Click **Logout** on any dashboard. | Returned to `login.html` with "You have been logged out." |
| 7.2 | Check DevTools → Local Storage. | `cms_token` and `cms_user` are gone. |
| 7.3 | Press the browser Back button / re-open a dashboard URL. | Redirected to login — the session is fully cleared. |

## 8. Health check

```bash
curl -s localhost:3000/api/health
# → { "success": true, "database": "connected", ... }
```

If MySQL is stopped before startup, the server prints a clear error and
exits instead of failing on the first request. If the database drops
while the server is already running, `/api/health` reports
`"database": "disconnected"` with status `503`.
