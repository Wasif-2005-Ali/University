-- ============================================================================
-- University Course Management System — Database Schema
-- Full Stack Development Lab 08 (CS-301L) | Air University, Kamra Campus
-- Teacher: M. Fahad Qasim | Student: Wasif Ali (BSCS-VB)
--
-- How to use (XAMPP):
--   1. Start Apache and MySQL from the XAMPP Control Panel.
--   2. Open phpMyAdmin (http://localhost/phpmyadmin) -> Import -> choose
--      this file -> Go.  (Or run: mysql -u root < database/schema.sql)
--   3. This creates the `UniversityDB` database with the `users` and
--      `courses` tables, one demo admin, one demo student and 6 courses.
--
-- Security notes:
--   * Passwords are NEVER stored in plain text. The seed accounts below
--     store bcrypt hashes (cost factor 10, same as the app uses).
--   * Demo passwords are for lab testing only — change them before any
--     real use, and never commit a real .env file.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS UniversityDB
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE UniversityDB;

-- ----------------------------------------------------------------------------
-- Table: users
--   role is 'student' by default. Public registration (POST /api/auth/register)
--   always forces 'student' — an admin account can only be created here
--   (or by an existing admin), never through the registration form.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('student', 'admin') NOT NULL DEFAULT 'student',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- Table: courses
--   created_by links a course to the admin who added it (NULL if that
--   admin account is later deleted).
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS courses (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  course_code VARCHAR(20)  NOT NULL UNIQUE,
  course_name VARCHAR(150) NOT NULL,
  instructor  VARCHAR(100) NULL,
  credits     INT NOT NULL DEFAULT 3,
  description TEXT NULL,
  created_by  INT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_courses_created_by
    FOREIGN KEY (created_by) REFERENCES users (id)
    ON DELETE SET NULL,
  CONSTRAINT chk_courses_credits CHECK (credits BETWEEN 1 AND 6)
) ENGINE = InnoDB;

-- ----------------------------------------------------------------------------
-- Seed data — demo accounts (passwords are bcrypt hashes, cost 10)
--   Admin:   admin@au.edu.pk   / Admin@123
--   Student: student@au.edu.pk / Student@123
--   Registering through the app always creates a student; log in as the
--   admin above to test the Admin Dashboard and course management.
--   INSERT ... ON DUPLICATE KEY UPDATE makes re-importing this file safe.
-- ----------------------------------------------------------------------------
INSERT INTO users (full_name, email, password_hash, role) VALUES
  ('Admin User', 'admin@au.edu.pk',
   '$2b$10$vVV5WTC0ieW2D/atFBU3NOkPMVUmB0NweMZmHmLYw2a5KCWzEa/ES', 'admin'),
  ('Demo Student', 'student@au.edu.pk',
   '$2b$10$pKhNwpomUrN.lvoVcr35zOA5lTokIpG5Ts7CZ62n1pgUbB1JRO5g.', 'student')
ON DUPLICATE KEY UPDATE
  full_name = VALUES(full_name),
  password_hash = VALUES(password_hash),
  role = VALUES(role);

-- Sample courses, credited to the demo admin account.
INSERT INTO courses (course_code, course_name, instructor, credits, description, created_by) VALUES
  ('CS-301', 'Full Stack Development', 'M. Fahad Qasim', 3,
   'Full stack web development with Node.js, Express.js, MySQL and jQuery.',
   (SELECT id FROM users WHERE email = 'admin@au.edu.pk')),
  ('CS-201', 'Data Structures and Algorithms', 'Dr. Ayesha Khan', 3,
   'Arrays, linked lists, trees, graphs, sorting and searching.',
   (SELECT id FROM users WHERE email = 'admin@au.edu.pk')),
  ('CS-102', 'Programming Fundamentals', 'M. Bilal Ahmed', 3,
   'Programming basics, problem solving and structured programming in C++.',
   (SELECT id FROM users WHERE email = 'admin@au.edu.pk')),
  ('MTH-101', 'Calculus and Analytical Geometry', 'Dr. Sana Raza', 3,
   'Limits, derivatives, integrals and analytical geometry.',
   (SELECT id FROM users WHERE email = 'admin@au.edu.pk')),
  ('CS-302', 'Database Systems', 'M. Fahad Qasim', 3,
   'Relational databases, SQL, normalisation and transactions.',
   (SELECT id FROM users WHERE email = 'admin@au.edu.pk')),
  ('CS-401', 'Artificial Intelligence', 'Dr. Ayesha Khan', 3,
   'Search, knowledge representation, machine learning and neural networks.',
   (SELECT id FROM users WHERE email = 'admin@au.edu.pk'))
ON DUPLICATE KEY UPDATE
  course_name = VALUES(course_name),
  instructor  = VALUES(instructor),
  credits     = VALUES(credits),
  description = VALUES(description);
