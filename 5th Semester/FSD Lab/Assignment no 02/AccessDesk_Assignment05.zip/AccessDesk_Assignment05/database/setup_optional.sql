-- =====================================================================
--  OPTIONAL setup for AccessDesk (Assignment 05)
--  The lecture database already contains mydb8.customers4, so normally
--  you do NOT need this file. Import it only if the table is missing.
--  It never drops or changes existing data: the sample rows are
--  inserted only when customers4 is empty.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS mydb8;
USE mydb8;

CREATE TABLE IF NOT EXISTS customers4 (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  name     VARCHAR(100) NOT NULL,
  address  VARCHAR(200) NOT NULL
);

INSERT INTO customers4 (name, address)
SELECT t.name, t.address FROM (
  SELECT 'Ali Raza' AS name, 'Taxila' AS address
  UNION ALL SELECT 'Alina Shah', 'Wah Cantt'
  UNION ALL SELECT 'Ali Hamza', 'Rawalpindi'
  UNION ALL SELECT 'Bilal Ahmed', 'Islamabad'
  UNION ALL SELECT 'Hina Malik', 'Kamra'
  UNION ALL SELECT 'Usman Tariq', 'Attock'
  UNION ALL SELECT 'Sana Iqbal', 'Hassan Abdal'
  UNION ALL SELECT 'Farhan Saeed', 'Fateh Jang'
  UNION ALL SELECT 'Maryam Khan', 'Peshawar'
  UNION ALL SELECT 'Zain Abbas', 'Lahore'
  UNION ALL SELECT 'Areeba Noor', 'Murree'
  UNION ALL SELECT 'Daniyal Butt', 'Gujranwala'
  UNION ALL SELECT 'Kinza Aslam', 'Sialkot'
  UNION ALL SELECT 'Hamza Qureshi', 'Multan'
  UNION ALL SELECT 'Laiba Rauf', 'Abbottabad'
  UNION ALL SELECT 'Saad Mehmood', 'Mardan'
  UNION ALL SELECT 'Noor Fatima', 'Haripur'
  UNION ALL SELECT 'Talha Javed', 'Chakwal'
  UNION ALL SELECT 'Rabia Anwar', 'Jhelum'
  UNION ALL SELECT 'Imran Yousaf', 'Sargodha'
  UNION ALL SELECT 'Mahnoor Ejaz', 'Faisalabad'
  UNION ALL SELECT 'Shahzaib Ali', 'Mianwali'
  UNION ALL SELECT 'Iqra Nadeem', 'Bahawalpur'
  UNION ALL SELECT 'Waleed Akram', 'Quetta'
  UNION ALL SELECT 'Ayesha Kamran', 'Karachi'
) AS t
WHERE (SELECT COUNT(*) FROM customers4) = 0;
