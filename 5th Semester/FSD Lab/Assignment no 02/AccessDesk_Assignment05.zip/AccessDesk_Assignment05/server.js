// =====================================================================
//  AccessDesk - Role-Based Customer Access Portal  (Assignment 05)
//  Existing database: mydb8   |   Existing table: customers4
//  Every permission decision is made HERE, never in browser JavaScript.
// =====================================================================
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;
const DATABASE = 'mydb8';
const TABLE = 'customers4';

/* ---------------------------------------------------------------
   CORS: only pages served from localhost / 127.0.0.1 (any port)
   may call this API. x-api-key is a custom header, so the browser
   sends an OPTIONS preflight first; the cors middleware answers it.
---------------------------------------------------------------- */
const ALLOWED_ORIGIN = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;
app.use(cors({
  origin: function (origin, callback) {
    // no Origin header = same-origin page, curl or Postman
    callback(null, !origin || ALLOWED_ORIGIN.test(origin));
  },
  methods: ['GET'],
  allowedHeaders: ['Content-Type', 'x-api-key']
}));

/* ---------------------------------------------------------------
   Database connection (credentials stay on the server only)
---------------------------------------------------------------- */
const db = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: DATABASE,
  connectionLimit: 10
});

/* ---------------------------------------------------------------
   Four API-key profiles (demo keys; credits are kept in memory)
---------------------------------------------------------------- */
const USERS = {
  'guest-key-000': {
    role: 'guest', allowedDatabases: [DATABASE], allowedTables: [TABLE],
    allowedActions: ['load'], visibleFields: ['name'],
    maxRows: 2, credits: 4
  },
  'student-key-123': {
    role: 'student', allowedDatabases: [DATABASE], allowedTables: [TABLE],
    allowedActions: ['load', 'search'], visibleFields: ['name', 'address'],
    maxRows: 3, credits: 8
  },
  'teacher-key-456': {
    role: 'teacher', allowedDatabases: [DATABASE], allowedTables: [TABLE],
    allowedActions: ['load', 'search'], visibleFields: ['name', 'address'],
    maxRows: 10, credits: 30
  },
  'admin-key-789': {
    role: 'admin', allowedDatabases: [DATABASE], allowedTables: [TABLE],
    allowedActions: ['load', 'search', 'usage'], visibleFields: ['name', 'address'],
    maxRows: 20, credits: 50
  }
};
const INITIAL_CREDITS = {};
Object.values(USERS).forEach(function (u) { INITIAL_CREDITS[u.role] = u.credits; });

/* Column names come from this fixed whitelist, never from the request.
   A role only receives the columns listed in its visibleFields, so the
   guest's SQL does not even select the address column. */
const COLUMNS = { name: 'name', address: 'address' };
function selectSql(user) {
  const cols = user.visibleFields.map(function (f) {
    if (!Object.hasOwn(COLUMNS, f)) throw new Error('Unknown column: ' + f);
    return COLUMNS[f];
  });
  return 'SELECT ' + cols.join(', ') + ' FROM ' + TABLE;
}

/* ---------------------------------------------------------------
   Access-control middleware
   authorize(action) checks, in this order:
     1. API key / identity            -> 401
     2. permitted action              -> 403
     3. allowed database and table    -> 403
     4. remaining credits             -> 429
   It never touches the credit counter or MySQL.
---------------------------------------------------------------- */
function denied(res, status, message, user) {
  const body = { message: message };
  if (user) body.meta = { role: user.role, remainingCredits: Math.max(user.credits, 0) };
  return res.status(status).json(body);
}

function authorize(action) {
  return function (req, res, next) {
    const key = req.get('x-api-key');
    const user = key && Object.hasOwn(USERS, key) ? USERS[key] : null;

    if (!user) {
      return denied(res, 401, 'Unauthorized: invalid or missing API key');
    }
    if (!user.allowedActions.includes(action)) {
      return denied(res, 403, 'Forbidden: ' + action + ' is not permitted for the ' + user.role + ' role', user);
    }
    if (!user.allowedDatabases.includes(DATABASE)) {
      return denied(res, 403, 'Forbidden: database access denied', user);
    }
    if (!user.allowedTables.includes(TABLE)) {
      return denied(res, 403, 'Forbidden: table access denied', user);
    }
    if (user.credits <= 0) {
      return denied(res, 429, 'Too Many Requests: no credits left for the ' + user.role + ' role', user);
    }
    req.currentUser = user;
    next();
  };
}

// One approved request = one credit. Called only after every check passed
// (including input validation), right before SQL is executed.
function spendCredit(req, res, next) {
  req.currentUser.credits -= 1;
  req.creditSpent = true;
  next();
}

function refundCredit(req) {
  if (req.creditSpent) { req.currentUser.credits += 1; req.creditSpent = false; }
}

function dbError(req, res, err) {
  console.error('MySQL error:', err.message);
  refundCredit(req);                      // the user got nothing, so no credit is lost
  return res.status(500).json({ message: 'Database error: check that MySQL is running and mydb8.customers4 exists' });
}

/* ---------------------------------------------------------------
   Row limit: Load uses min(requestedRows, maxRows)
---------------------------------------------------------------- */
function parseRequested(input) {
  const n = Number(input);
  return Number.isInteger(n) && n >= 1 ? n : null;
}
function getAllowedRows(input, maxRows) {
  const requested = parseRequested(input);
  return Math.min(requested === null ? maxRows : requested, maxRows);
}

function meta(user, extra) {
  return Object.assign({
    role: user.role,
    remainingCredits: user.credits,
    database: DATABASE,
    table: TABLE,
    fields: user.visibleFields
  }, extra);
}

// escape LIKE wildcards typed by the user so "%" or "_" are searched literally
function escapeLike(text) { return text.replace(/[\\%_]/g, '\\$&'); }

/* ---------------------------------------------------------------
   Route 1: Load Customers      GET /api/customers?limit=10
---------------------------------------------------------------- */
app.get('/api/customers', authorize('load'), spendCredit, function (req, res) {
  const user = req.currentUser;
  const requested = parseRequested(req.query.limit);
  const limit = getAllowedRows(req.query.limit, user.maxRows);

  db.query(selectSql(user) + ' LIMIT ?', [limit], function (err, rows) {
    if (err) return dbError(req, res, err);
    res.json({
      meta: meta(user, { requestedRows: requested, allowedRows: limit, returnedRows: rows.length }),
      data: rows
    });
  });
});

/* ---------------------------------------------------------------
   Route 2: Search Customers    GET /api/customers/search?name=Ali
   Guest is denied by authorize('search'). Uses the role's maxRows.
---------------------------------------------------------------- */
function validateSearch(req, res, next) {
  const name = typeof req.query.name === 'string' ? req.query.name.trim() : '';
  if (!name) {
    return denied(res, 400, 'Bad Request: enter a customer name to search', req.currentUser);
  }
  if (name.length > 50) {
    return denied(res, 400, 'Bad Request: search text is too long (max 50 characters)', req.currentUser);
  }
  req.searchName = name;
  next();
}

app.get('/api/customers/search', authorize('search'), validateSearch, spendCredit, function (req, res) {
  const user = req.currentUser;
  const pattern = '%' + escapeLike(req.searchName) + '%';
  const limit = user.maxRows;

  db.query(selectSql(user) + ' WHERE name LIKE ? LIMIT ?', [pattern, limit], function (err, rows) {
    if (err) return dbError(req, res, err);
    res.json({
      meta: meta(user, { search: req.searchName, allowedRows: limit, returnedRows: rows.length }),
      data: rows
    });
  });
});

/* ---------------------------------------------------------------
   Route 3: Usage summary       GET /api/access/summary   (admin only)
   Returns credits per role. API keys are never included.
---------------------------------------------------------------- */
app.get('/api/access/summary', authorize('usage'), spendCredit, function (req, res) {
  const user = req.currentUser;
  const roles = Object.values(USERS).map(function (u) {
    return {
      role: u.role,
      maxRows: u.maxRows,
      totalCredits: INITIAL_CREDITS[u.role],
      creditsUsed: INITIAL_CREDITS[u.role] - u.credits,
      creditsLeft: u.credits
    };
  });
  res.json({ meta: meta(user), data: roles });
});

/* ---------------------------------------------------------------
   Utility routes, frontend and error handling
---------------------------------------------------------------- */
app.get('/api/health', function (req, res) { res.json({ status: 'AccessDesk API is running' }); });

app.use(express.static(path.join(__dirname, 'public')));   // optional: http://localhost:3000

app.use('/api', function (req, res) { res.status(404).json({ message: 'API endpoint not found' }); });

app.use(function (err, req, res, next) {
  console.error('Server error:', err.message);
  refundCredit(req);
  res.status(500).json({ message: 'Internal server error' });
});

app.listen(PORT, function () {
  console.log('AccessDesk API ready on http://localhost:' + PORT);
  Object.entries(USERS).forEach(function (e) {
    const u = e[1];
    console.log('  ' + u.role.padEnd(8) + 'maxRows=' + String(u.maxRows).padEnd(3) + 'credits=' + u.credits + '  fields=' + u.visibleFields.join(','));
  });
  db.getConnection(function (err, conn) {
    if (err) console.error('MySQL connection FAILED:', err.message);
    else { console.log('MySQL connected to ' + DATABASE + '.' + TABLE); conn.release(); }
  });
});
