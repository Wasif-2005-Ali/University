# AccessDesk - Role-Based Customer Access Portal (Assignment 05)

Node.js + Express + MySQL (XAMPP) + jQuery AJAX. Uses the existing lecture database
`mydb8`, table `customers4` (columns `name`, `address`). Do NOT change the existing data.

## Run steps
1. XAMPP Control Panel -> start **MySQL** (Apache is optional).
2. Confirm `mydb8.customers4` exists in phpMyAdmin.
   If it does not, import `database/setup_optional.sql` (adds sample rows only when the table is empty).
3. Open this folder in a terminal and run:
   ```
   npm install
   node server.js
   ```
   (or double-click `START_NODE_SERVER.bat`)
4. Open **http://localhost:3000** in the browser.

Alternative (lecture style): copy `public/index.html` and `public/jquery.min.js` to
`C:\xampp\htdocs\accessdesk\` and open `http://localhost/accessdesk/index.html`.
Do not double-click the HTML file (file:// pages cannot pass CORS).

Restart Node.js before the verification sequence so every role starts with full credits.

## Demo API keys (local demo only)
| Role    | Key             | Max rows | Credits | Actions               | Fields        |
|---------|-----------------|----------|---------|-----------------------|---------------|
| Guest   | guest-key-000   | 2        | 4       | Load                  | Name          |
| Student | student-key-123 | 3        | 8       | Load + Search         | Name, Address |
| Teacher | teacher-key-456 | 10       | 30      | Load + Search         | Name, Address |
| Admin   | admin-key-789   | 20       | 50      | Load + Search + Usage | Name, Address |

## Routes (send the key in the `x-api-key` header)
- `GET /api/customers?limit=10` - Load, uses min(requestedRows, maxRows)
- `GET /api/customers/search?name=Ali` - Search with a bound LIKE value (Guest -> 403)
- `GET /api/access/summary` - Admin only, credits per role (never returns keys)

## Verification cases
| Try this                        | Expected                              |
|---------------------------------|---------------------------------------|
| Unknown API key                 | 401, no customer records              |
| Guest loads 10                  | 200, at most 2 names, no addresses    |
| Guest attempts Search           | 403                                   |
| Student loads 10                | 200, at most 3 records                |
| Teacher loads 10                | 200, at most 10 records               |
| Student 9th request             | 429, no records                       |
| Non-admin opens usage           | 403                                   |

Notes: credits are kept in memory (restart resets them). A rejected request (401/403/400)
does not use a credit; every approved request uses one. MySQL settings live only in `server.js`.
The full report with screenshots is `AccessDesk_Report.docx`.
